# [Brofiler: C++ Profiler For Games](http://brofiler.com)
Warning! This project is under extremely active development at the moment. 
Please use the latest [stable version](https://github.com/bombomby/brofiler/releases).

## Build status
[![Build status](https://ci.appveyor.com/api/projects/status/bu5smbuh1d2lcsf6?svg=true)](https://ci.appveyor.com/project/bombomby/brofiler)

## [Tutorial](https://github.com/bombomby/brofiler/wiki)   
![](http://brofiler.com/images/screenshots/Screen0.png)
[![Analytics](https://ga-beacon.appspot.com/UA-59213040-1/brofiler/readme)](https://github.com/bombomby/brofiler)